---
type: Catalogue record
title: Prepare for the CAF for local government
description: 'Guidance on how to decide the scope of your CAF for local government
  self-assessment and who needs to be involved. Catalogue section: Cyber Assessment
  Framework (CAF) for local government. Source page updated: 24 March 2025. Browse
  assurance, cyber security. Public page.'
status: draft
generated:
  at: '2026-10-31T21:30:00Z'
  by: process:public-security-discovery/1
---

# Prepare for the CAF for local government

**Source access: Public page.**

Source page updated: 24 March 2025. This is the source page's displayed date, not an event date.

## Public listing abstract

Guidance on how to decide the scope of your CAF for local government self-assessment and who needs to be involved.

## Find your way

Guidance on how to decide the scope of your CAF for local government self-assessment and who needs to be involved. Catalogue section: Cyber Assessment Framework (CAF) for local government. Source page updated: 24 March 2025. Browse assurance, cyber security. Public page.

Source URL sections: [Cyber Assessment Framework (CAF) for local government](entry-5f9e4f43a3e26fc77b24.md). This is URL-based navigation, not a description of the protected source.

Open topic guides: [Assurance](../topics/assurance.md), [Cyber security](../topics/cyber-security.md).

## Linked from public pages

These open pages link to this catalogue entry. Their links do not establish what the protected source contains.

- [Cyber Assessment Framework (CAF) for local government](entry-5f9e4f43a3e26fc77b24.md)
- [How the CAF relates to other cyber standards](entry-479edaffd99cb5c80cb1.md)
- [What the CAF for local government involves](entry-6a29c619d4341a9e35ac.md)

[Open the original source](https://www.security.gov.uk/policy-and-guidance/cyber-assessment-framework-caf-for-local-government/prepare/)

Based on the public portal listing observed on 31 October 2026. Only the public listing abstract is retained; attached files need separate review. [About this catalogue](../method.md).

## Suggested open background

Selected using public title matches or source URL sections. These are discovery suggestions, not summaries or requirements of the sign-in source.

- [Cyber Assessment Framework (CAF) for local government](entry-5f9e4f43a3e26fc77b24.md)
- [GovAssure](entry-114ec202b3f1296b9ee2.md)
- [Secure by Design](entry-60e4ba50ee0b5e11c143.md)

