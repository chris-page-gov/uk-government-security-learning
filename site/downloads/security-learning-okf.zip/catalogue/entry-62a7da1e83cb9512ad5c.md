---
type: Catalogue record
title: 'Stage 4: Complete a Peer Review using WebCAF'
description: 'The guidance on this page is for reviewers conducting a Peer Review
  of an organisation’s WebCAF self-assessment. Catalogue section: GovAssure guidance.
  Source page updated: 11 March 2026. Browse assurance, cyber security. Public page.'
status: draft
generated:
  at: '2026-10-31T21:30:00Z'
  by: process:public-security-discovery/1
---

# Stage 4: Complete a Peer Review using WebCAF

**Source access: Public page.**

Source page updated: 11 March 2026. This is the source page's displayed date, not an event date.

## Public listing abstract

The guidance on this page is for reviewers conducting a Peer Review of an organisation’s WebCAF self-assessment.

## Find your way

The guidance on this page is for reviewers conducting a Peer Review of an organisation’s WebCAF self-assessment. Catalogue section: GovAssure guidance. Source page updated: 11 March 2026. Browse assurance, cyber security. Public page.

Source URL sections: [GovAssure](entry-114ec202b3f1296b9ee2.md) → [GovAssure guidance](entry-56b7384efc0dfcb5ad8b.md). This is URL-based navigation, not a description of the protected source.

Open topic guides: [Assurance](../topics/assurance.md), [Cyber security](../topics/cyber-security.md).

## Linked from public pages

These open pages link to this catalogue entry. Their links do not establish what the protected source contains.

- [Stage 4: Complete an Independent Assurance Review using WebCAF](entry-ae1b00141fd00e129fd8.md)
- [Stage 4: Have a Peer Review](entry-a39ab0a07f380d9253fa.md)
- [Supporting arm's length bodies (ALBs)](entry-76196c60ac2d0632a22c.md)

[Open the original source](https://www.security.gov.uk/policy-and-guidance/govassure/govassure-guidance/stage-4-complete-a-peer-review-using-webcaf/)

Based on the public portal listing observed on 31 October 2026. Only the public listing abstract is retained; attached files need separate review. [About this catalogue](../method.md).

## Suggested open background

Selected using public title matches or source URL sections. These are discovery suggestions, not summaries or requirements of the sign-in source.

- [GovAssure](entry-114ec202b3f1296b9ee2.md)
- [GovAssure guidance](entry-56b7384efc0dfcb5ad8b.md)
- [Secure by Design](entry-60e4ba50ee0b5e11c143.md)

