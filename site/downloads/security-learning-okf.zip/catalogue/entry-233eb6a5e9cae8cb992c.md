---
type: Catalogue record
title: 'Espionage: Risks in election environments'
description: 'Catalogue section: GSeC International. Source page updated: 29 April
  2026. Browse risk management, overseas security. Sign-in required; this note uses
  public metadata only.'
status: draft
generated:
  at: '2026-10-31T21:30:00Z'
  by: process:public-security-discovery/1
---

# Espionage: Risks in election environments

**Source access: Sign-in required.**

Source page updated: 29 April 2026. This is the source page's displayed date, not an event date.

## Find your way

Catalogue section: GSeC International. Source page updated: 29 April 2026. Browse risk management, overseas security. Sign-in required; this note uses public metadata only.

Source URL sections: [GSeC International](entry-d62a71292a36eeeb4ca1.md). This is URL-based navigation, not a description of the protected source.

Open topic guides: [Risk management](../topics/risk-management.md), [Overseas security](../topics/overseas-security.md).

[Open the original source — sign-in required](https://www.security.gov.uk/policy-and-guidance/gsec-international/espionage-espionage-risks-in-election-environments/)

Based on the public portal listing observed on 31 October 2026. No abstract of the protected source is included. [About this catalogue](../method.md).

## Suggested open background

Selected using public title matches or source URL sections. These are discovery suggestions, not summaries or requirements of the sign-in source.

- [GSeC International](entry-d62a71292a36eeeb4ca1.md)
- [Overseas travel: Staying safe on official visits](entry-c11381f9036af3cba0d7.md)
- [Overseas travel: Staying safe on official visits](entry-e93aaee276ebd1879ccc.md)

