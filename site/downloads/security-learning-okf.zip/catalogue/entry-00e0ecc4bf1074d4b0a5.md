---
type: Catalogue record
title: How to complete a self-assessment workbook
description: 'What to consider when completing your CAF for local government self-assessment
  – from who to involve, to sharing with your assurer. Catalogue section: Complete
  your self-assessment. Source page updated: 14 January 2026. Browse assurance, cyber
  security. Public page.'
status: draft
generated:
  at: '2026-10-31T21:30:00Z'
  by: process:public-security-discovery/1
---

# How to complete a self-assessment workbook

**Source access: Public page.**

Source page updated: 14 January 2026. This is the source page's displayed date, not an event date.

## Public listing abstract

What to consider when completing your CAF for local government self-assessment – from who to involve, to sharing with your assurer.

## Find your way

What to consider when completing your CAF for local government self-assessment – from who to involve, to sharing with your assurer. Catalogue section: Complete your self-assessment. Source page updated: 14 January 2026. Browse assurance, cyber security. Public page.

Source URL sections: [Cyber Assessment Framework (CAF) for local government](entry-5f9e4f43a3e26fc77b24.md) → [Complete your self-assessment](entry-990dd2b50f916d65fb01.md). This is URL-based navigation, not a description of the protected source.

Open topic guides: [Assurance](../topics/assurance.md), [Cyber security](../topics/cyber-security.md).

## Linked from public pages

These open pages link to this catalogue entry. Their links do not establish what the protected source contains.

- [Complete your self-assessment](entry-990dd2b50f916d65fb01.md)

[Open the original source](https://www.security.gov.uk/policy-and-guidance/cyber-assessment-framework-caf-for-local-government/complete-your-self-assessment/how-to-complete-a-self-assessment-workbook/)

Based on the public portal listing observed on 31 October 2026. Only the public listing abstract is retained; attached files need separate review. [About this catalogue](../method.md).

## Suggested open background

Selected using public title matches or source URL sections. These are discovery suggestions, not summaries or requirements of the sign-in source.

- [Cyber Assessment Framework (CAF) for local government](entry-5f9e4f43a3e26fc77b24.md)
- [Complete your self-assessment](entry-990dd2b50f916d65fb01.md)
- [GovAssure](entry-114ec202b3f1296b9ee2.md)

